const mysql = require("mysql2")

const db = mysql.createConnection({
            host:"localhost",
            user:"root",
            password:"root123",
            database:"ecom"
})

db.connect((err,result)=>{
    if(err){
        console.log("Error at Db ",err.message);
    }else {
        console.log("Connected to Database");
    }
})

module.exports = db