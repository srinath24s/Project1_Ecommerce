const db = require("./connection")
const app = require("./index")
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");

// middleware functions


// Password Encrypting
const encryptPassword = async (req,res,next)=>{
    const {password,...rest} = req.body
    const hassedPassword = await bcrypt.hash(password,10);
   // console.log(hassedPassword)
    req.encryptedPassword =hassedPassword;
    req.restDetails = rest;
    console.log("Password Encrypted Completed...");
    next();
}

// Verifing Password with Database Password
const decryptPassword = async (req,res,next)=>{
    const {Username,Password}=req.body
    let Query = `SELECT * FROM users WHERE username="${Username}";`
    // console.log(Query);
    db.query(Query, async (error,result)=>{
       if(error){
        res.send({success:`Bad Request:- ${error.message}`})
       }else if(result == ""){
        res.send({success:"Not Account Found"})
       }else{

        //  console.log("HEllo",result)
        const dbPassword = result[0].password;
        console.log(dbPassword)
        let verifyPassword = await bcrypt.compare(Password,dbPassword);
        req.Password = verifyPassword // verifyPassword will get only true or false // use password to get password of actual one
        req.Username = result[0].username
        req.userId = result[0].id
        console.log("Password Decryption Completed...");
        next();
       }
    })
   
}

// Generate Token
const tokenGenerate = (req,res,next)=>{
    const {userId,Username,Password} = req  // Getting From Middleware Function
    if(Password === false){
        res.send({success:"Wrong Password"})
    }else{
        let payload= {username:Username,user_id:userId}
        let token = jwt.sign(payload,"MY_TOKEN");
        //console.log(payload)
        req.token = token 
        console.log("Token Generated...");
        next();
     
    }
}

// token verify 
const tokenVerify =  (req,res,next)=>{
    const gettingTokenCode = req.headers["authorization"]    
    if(gettingTokenCode === undefined){
        res.status(401)
        res.send({success:"Un Authorization Access"})
    }else{
        const bearerTokenCode = `Bearer ${gettingTokenCode}`.split(" ")[2];
        console.error("Split Token  ",bearerTokenCode);
        jwt.verify(bearerTokenCode,"MY_TOKEN",(err,payload)=>{
            if(err){
                res.status(401)
                res.send({success:`Error at token Verification   -  ${err.message}`})
            }else{
               //console.log("payload",payload);
                req.User=payload  // used to pass middleware data into handlers Functions
                res.status(200)
                console.log("Token Verification Completed...");
                next();                                                         
            }
        })

    }
}


app.get("/products",(req,res)=>{
    let Query = `SELECT * FROM products;`
    db.query(Query,(err,Data)=>{
        if(err){
            res.status(400)
            res.send(err.message)
        }else {
            res.status(200)
            res.send(Data);
        }
    })
})
app.post("/register",encryptPassword,(req,res)=>{
    const {encryptedPassword,restDetails} =req
    const {name,email,contact,username}=restDetails;
    console.log(name);
    let Query = `INSERT INTO users(name,ph_no,email,username,password)
    VALUES("${name}","${contact}","${email}","${username}","${encryptedPassword}");`
    db.query(Query,(err)=>{
        if(err){
            res.send({success:err.message})
        }else {
            res.send({success:"OK"})
        }
    })

})
app.post("/login",decryptPassword,tokenGenerate,(req,res)=>{
    const {token}=req
    console.log("JWTToken - ",token)
   res.send({Token : token,
    success:"OK"})    
})
app.get("/cart",tokenVerify,(req,res)=>{
    const {User} =req;
    const {username,user_id} =User;
    // res.status(200).send("Hello")
    let Query = `
        SELECT users.username , products.id,products.name,products.image,products.description,products.rating,products.price
        FROM users
        INNER JOIN cart ON cart.user_id = users.id
        INNER JOIN products ON cart.product_id = products.id 
        where users.id = ${user_id};
    `
    db.query(Query,(err,Data)=>{
        if(err){
            res.status(400)
            res.send(err)
        }else {
            res.status(200)
            if(Data == "") {
                res.send("NO Products")
            }else{
                res.send(Data);
            }
        }
    })
})
app.post("/cart",tokenVerify,(req,res)=>{
    const {User} =req;
    const {username,user_id}=User;
    let Query = `
        INSERT INTO orders (user_id,product_id,address_id)VALUES (${user_id},${2},${3});
    `
    db.query(Query,(err,Data)=>{
        if(err){
            res.status(400)
            res.send(err)
        }else {
            
            // res.send(Data);
            if(Data.affectedRows != 0){
                res.status(200)
                res.send("product added to cart")
            }else {
                res.status(400)
                res.send("not added to cart")
            }
        }
    })
})
app.get("/orders/:id",tokenVerify,(req,res)=>{
    // res.status(200).send("Hello")
    const id = req.params.id;
    let Query = `
        SELECT users.id,users.username,
        products.id,products.name,products.image,products.description,products.rating,products.price,
        address.addressline1,address.addressline2,address.landmark,
        pincode.pincode,pincode.city,pincode.state
        FROM users
        INNER JOIN orders ON users.id = orders.user_id
        INNER JOIN products on orders.product_id = products.id
        INNER JOIN address on orders.address_id = address.id
        INNER JOIN pincode ON address.pincode_id =pincode.id
        WHERE users.id = ${id};
    `
    db.query(Query,(err,Data)=>{
        if(err){
            res.status(400)
            res.send(err.message)
        }else {
            res.status(200)
            res.send(Data);
        }
    })
})
app.post("/help",tokenVerify,(req,res)=>{
    // res.status(200).send("Hello")
    res.send("Hello")
})
app.get("/logout",(req,res)=>{
   // window.location.href='./home.html'
    res.status(200).send("Logout Succesfull")
})
