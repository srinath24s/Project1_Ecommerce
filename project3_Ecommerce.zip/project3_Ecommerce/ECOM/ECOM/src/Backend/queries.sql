CREATE DATABASE ecom;

USE ecom;

-- // CREATING users TABLE
CREATE TABLE  users(
id  INT  PRIMARY KEY NOT NULL UNIQUE AUTO_INCREMENT,
name VARCHAR(255) NOT NULL DEFAULT  'user' ,
ph_no VARCHAR(15) NOT NULL UNIQUE,
email VARCHAR(255) UNIQUE ,
username VARCHAR(255) UNIQUE NOT NULL,
password  VARCHAR(1000) NOT NULL,
created_date  DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- // CREATING products TABLE

CREATE TABLE  products(
id  INT  PRIMARY KEY NOT NULL UNIQUE AUTO_INCREMENT,
name VARCHAR(255) NOT NULL DEFAULT  'item' ,
image BLOB NOT NULL ,
description TEXT  ,
rating VARCHAR(15)  NOT NULL,
price  DECIMAL(20,2) NOT NULL
);

-- // CREATING cart TABLE

CREATE TABLE  cart(
id  INT  PRIMARY KEY NOT NULL UNIQUE AUTO_INCREMENT,
user_id INT NOT NULL,
product_id INT NOT NULL,
FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- // CREATING favourite TABLE

CREATE TABLE  favourite(
id  INT  PRIMARY KEY NOT NULL UNIQUE AUTO_INCREMENT,
user_id INT NOT NULL,
product_id INT NOT NULL,
FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- // CREATING saveLater TABLE

CREATE TABLE  saveLater(
id  INT  PRIMARY KEY NOT NULL UNIQUE AUTO_INCREMENT,
user_id INT NOT NULL,
product_id INT NOT NULL,
FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- // CREATING pincode TABLE

CREATE TABLE  pincode(
id  INT  PRIMARY KEY NOT NULL UNIQUE AUTO_INCREMENT,
pincode VARCHAR(255) NOT NULL UNIQUE,
city VARCHAR(255) NOT NULL,
state VARCHAR(255) NOT NULL 
);

-- // CREATING address TABLE

CREATE TABLE  address(
id  INT  PRIMARY KEY NOT NULL UNIQUE AUTO_INCREMENT,
addressline1 VARCHAR(255) NOT NULL  ,
addressline2 VARCHAR(255) ,
landmark VARCHAR(255) ,
pincode_id INT NOT NULL,
FOREIGN KEY(pincode_id) REFERENCES pincode(id) ON DELETE CASCADE
);

-- // CREATING orders TABLE

CREATE TABLE  orders(
id  INT  PRIMARY KEY NOT NULL UNIQUE AUTO_INCREMENT,
user_id INT NOT NULL,
product_id INT NOT NULL,
address_id INT NOT NULL,
ordered_date DATETIME  DEFAULT CURRENT_TIMESTAMP,
FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE,
FOREIGN KEY(address_id) REFERENCES address(id) ON DELETE CASCADE
);


-- // INSERTING DATA INTO ABOVE TABLES




INSERT INTO `users` VALUES (1,'Dinakar','9052175420','sdinakarbab@gmail.com','Dinakarbabu',_binary '12345','2024-06-30 11:42:47'),(2,'srinath','9523834821','srinath@gmail.com','srinath',_binary '12348','2024-07-09 13:34:18'),(3,'shankar','6305762197','shankar@gmail.com','shankar',_binary '12310','2024-07-09 13:34:18'),(4,'praneeth','95156365399','praneeth@gmail.com','praneeth',_binary '12343','2024-07-09 13:34:18'),(5,'saif','9000944700','saif@gmail.com','saif',_binary '12348','2024-07-09 13:34:18'),(6,'arun','8523062539','arun@gmail.com','arun',_binary '12347','2024-07-09 13:34:18'),(7,'rishi','6300525352','rishi@gmail.com','rishi',_binary '12341','2024-07-09 13:34:18'),(8,'teju','8985033211','teju@gmail.com','teju',_binary '12342','2024-07-09 13:34:18'),(9,'manjio','9010766357','manjio@gmail.com','manjio',_binary '12343','2024-07-09 13:34:18'),(10,'sainath','9346082862','sainath@gmail.com','sainath',_binary '12346','2024-07-09 13:34:18');

INSERT INTO `products` VALUES (1,'Vivo',_binary './images','Hello Vivo Y100','4.5',28500.00),(2,'oppo',_binary './images','Hello oppo','3.5',18500.00),(3,'mi',_binary './images','Hello  mi','2.5',10500.00),(4,'iqoo',_binary './images','Hello iqoo','5.0',38500.00),(5,'google',_binary './images','Hello google','3.5',15000.00),(6,'moto',_binary './images','Hello moto','4.5',20000.00),(7,'infixe',_binary './images','Hello infixe','4.5',48500.00),(8,'moto ege',_binary './images','Hello moto ege','2.5',25500.00),(9,'mi pro',_binary './images','Hello mi pro','4.5',29500.00),(10,'oppo af',_binary './images','Hello oppo af','3.5',21500.00),(11,'oppo',_binary './images','Hello oppo','3.5',18500.00),(12,'mi',_binary './images','Hello  mi','2.5',10500.00),(13,'iqoo',_binary './images','Hello iqoo','5.0',38500.00),(14,'google',_binary './images','Hello google','3.5',15000.00),(15,'moto',_binary './images','Hello moto','4.5',20000.00),(16,'infixe',_binary './images','Hello infixe','4.5',48500.00),(17,'moto ege',_binary './images','Hello moto ege','2.5',25500.00),(18,'mi pro',_binary './images','Hello mi pro','4.5',29500.00),(19,'oppo af',_binary './images','Hello oppo af','3.5',21500.00);

INSERT INTO `pincode` VALUES (1,'522101','Guntur','Andhrapradresh'),(2,'522165','mancherial','telangana'),(3,'522118','chandrapur','maharastra'),(4,'522135','pune','maharastra'),(5,'522175','nagpur','maharastra'),(6,'522121','bellampelli','telangana'),(7,'522134','indaram','telangana'),(8,'522156','ramagundam','telangana'),(9,'522304','pedhapelli','telangana'),(10,'502117','aziznagar','telangana');


INSERT INTO `address` VALUES (1,'AmbedkarNagar','8th ward','Ambedkar Statue',1),(2,'aziznagar','9th ward','gandhi Statue',2),(3,'ccc colony','4h ward','indragandhi Statue',1),(4,'naspur colony','2th ward','mahi Statue',4),(5,'ramakrishnapuram','1th ward','prem statue',7),(6,'kokapet','18th ward','bank line',4),(7,'kukatpally','8th ward','metro station',3),(8,'kphb','17th ward','pillar no 99',9),(9,'nagol','44th ward','gas station',5),(10,'gopalapuram','7th ward','ntr crcile',6);


INSERT INTO `cart` VALUES (1,1,1),(2,1,3),(3,2,14),(4,4,18),(5,2,17),(6,7,15),(7,9,14),(8,5,19),(9,5,13),(10,6,9),(11,2,1),(12,9,8),(13,7,3),(14,3,7),(15,6,8),(16,5,1),(17,2,3),(18,10,2);

INSERT INTO `savelater` VALUES (1,1,1),(2,1,3),(3,2,14),(4,4,18),(5,2,17),(6,7,15),(7,9,14),(8,5,19),(9,5,13),(10,6,9),(11,2,1),(12,9,8),(13,7,3),(14,3,7),(15,6,8),(16,5,1),(17,2,3),(18,10,2);

INSERT INTO `favourite` VALUES (1,1,1),(2,1,5),(3,5,10),(6,10,10),(7,1,3),(8,2,14),(9,4,18),(10,2,17),(11,7,15),(12,9,14),(13,5,19),(14,5,13),(15,6,9),(16,2,1),(17,9,8),(18,7,3),(19,3,7),(20,6,8),(21,5,1),(22,2,3),(23,10,2);



INSERT INTO  orders(id,user_id,product_id,address_id)VALUES(
 1,1,1,1
);

SELECT * FROM products
INNER JOIN cart ON products.id = cart.product_id 
INNER JOIN users ON cart.user_id = users.id;
