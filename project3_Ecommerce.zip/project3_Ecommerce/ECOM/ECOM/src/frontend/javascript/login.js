// Page Changing
let signupContainer = document.getElementById("signupContainer");
let loginContainer = document.getElementById("loginContainer");
let changeSlideCreate = document.getElementById("changeSlideCreate");
let changeSlideLoginEle = document.getElementById("changeSlideLogin");

changeSlideLoginEle.addEventListener('click',()=>{
    signupContainer.classList.toggle("testLeft");
    loginContainer.classList.toggle("testLeft");
})
changeSlideCreate.addEventListener('click',()=>{
    signupContainer.classList.toggle("testLeft");
    loginContainer.classList.toggle("testLeft")
})


// Login Page Details
let usernameEle = document.getElementById("username");
let passwordEle = document.getElementById("password");
let loginSubmitEle = document.getElementById("loginSubmit");
let errorMessageEle = document.getElementById("errorMessage");
   
loginSubmitEle.addEventListener('click',()=>{
    var user =usernameEle.value;
    var pass = passwordEle.value;
    try {
        if(user !== user.toLowerCase()){
            
            errorMessageEle.textContent = "Entered details Incorrect"
        }
        else {
            let pattern =/^[a-z]+[a-z]$/;
            if(pattern.test(user)){
               document.cookie = `User =${user}`;
               errorMessageEle.textContent=`${document.cookie}`
               let data = {
                    User:user,
                    password:pass
                }
                console.log(data);
                window.location.href='../html/home.html';
                
            }else {
                errorMessageEle.textContent="Entered details Incorrect"
            }
            
        }

        //Login Details
        function backendData(data){
            // write Here code for data
            localStorage.setItem("token",data.Token)
            console.log("Done",data);
        }

        function sendingToServer(){
            const Data = {
                username:Username,
                password:Password
            }
            const url = "http://localhost:3000/login";
            const options = {
                method :"post",
                headers:{
                    'Content-Type':"application/json"
                },
                body:JSON.stringify(Data)
            }
            const fetchData =   fetch(url,options)
            .then((response)=> response.json())
            .then((data)=> backendData(data))
        }sendingToServer();
    }
    catch(err){
        errorMessageEle.textContent = err
    }
   
})
   



// Sign up page



let signupSubmitEle = document.getElementById("signupSubmit");
let errorIssuesEle = document.getElementById("errorIssues");

let firstNamePattern =/^[A-Z a-z]+[a-z]$/;
let lastNamePattern =/^[a-z]+[a-z]$/;
let usernamePattern =/^[a-z]+[a-z]$/;
let emailPattern = /^[a-z]+[a-z \d]+@[a-z]+?\.+[a-z]{2,3}$/;
let contactNumber = /^[0-9]+\d$/;


let Name="";
let Username="";
let Email="";
let Contact="";
let Password="";


signupSubmitEle.addEventListener('click',()=>{
    let firstNameEle = document.getElementById("firstName").value;
    let secondNameEle = document.getElementById("secondName").value;
    let usernameEle = document.getElementById("username").value;
    let emailEle = document.getElementById("email").value;
    let contactNumberEle = document.getElementById("contactNumber").value;
    let createPasswordEle = document.getElementById("createPassword").value;
    let confirmPasswordEle = document.getElementById("confirmPassword").value;
    try {
       
        //Register Details
        function backendData(data){   // Function definition
            // write Here code for using fetched data
            console.log("Done",data);
        }


        function sendingToServer(){
            const Data = {
                name:Name,
                username:Username,
                email:Email,
                contact:Contact,
                password:Password
            }
            const url = "http://localhost:3000/register";
            const options = {
                method :"post",
                headers:{
                    'Content-Type':"application/json"
                },
                body:JSON.stringify(Data)
            }
            const fetchData =   fetch(url,options)
            .then((response)=> response.json())
            .then((data)=> backendData(data))  // Function Calling 
        }sendingToServer();
    
    
    }catch(err){
        console.log(err)
    }
})





