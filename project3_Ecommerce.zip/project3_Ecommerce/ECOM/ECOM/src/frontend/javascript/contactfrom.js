   //Contact Form

function backendData(data){   // Function definition

    // write Here code for using fetched data

    console.log("Send Succesfully");
}


function sendingToServer(){
    const token = localStorage.getItem("token")
           // console.log(token)
        if(token == null){
            console.log("You are LogOuted")
        }else{
            const Data = {
                name:Name,
                username:Username,
                email:Email,
                contact:Contact,
                password:Password
            }
            const url = "http://localhost:3000/help";
            const options = {
                method :"post",
                headers:{
                    'Content-Type':"application/json",
                    "authorization":`Bearer ${token}`
                },
                body:JSON.stringify(Data)
            }
            const fetchData =   fetch(url,options)
            .then((response)=> response.json())
            .then((data)=> backendData(data))  // Function Calling 
        }
    
}sendingToServer();