function product() {
    let productsContainer = document.getElementById("cartContainer");
    let divOuterEle =document.createElement("div");
    divOuterEle.classList.add("eachItemContainer");
    productsContainer.appendChild(divOuterEle);
     
    let divEle =document.createElement("div");
    divEle.classList.add("eachProductContainer");
    divOuterEle.appendChild(divEle);

    let imgEle = document.createElement("img");
    imgEle.classList.add("eachProductContainerImg");
    imgEle.src = "../../../public/Assests/both.jpeg";
    imgEle.alt ="Product";
    divEle.appendChild(imgEle);

    let btnEle = document.createElement("button");
    btnEle.textContent="ADD TO CART";
    btnEle.classList.add("eachProductContainerBtn");
    divEle.appendChild(btnEle);


    
    let divSaveEle = document.createElement("div");
    divSaveEle.classList.add("fotter");
    divOuterEle.appendChild(divSaveEle);

    // let butEle = document.createElement("button");
    // butEle.textContent = "REMOVE";
    // butEle.classList.add("btn");
    // divSaveEle.appendChild(butEle);

    let buEle = document.createElement("button");
    buEle.textContent = "DELETE";
    buEle.classList.add("btn");
    divSaveEle.appendChild(buEle);


}

//cart button//
function cart(){

let divEle = document.createElement("div");
divEle.classList.add("fotter");
cartContainer.appendChild(divEle);

let butEle = document.createElement("button");
butEle.textContent = "REMOVE";
butEle.classList.add("btn");
divEle.appendChild(butEle);

let buEle = document.createElement("button");
buEle.textContent = "SAVE FOR LATER";
buEle.classList.add("btn");
divEle.appendChild(buEle);
}



// Backend Api 

function backendData(data){   // Function definition

    // write Here code for using fetched data
    product()
    console.log("Done",data);
}

function sendingToServer(){
    const token = localStorage.getItem("token")
    // console.log(token)
    if(token == null){
        console.log("You are LogOuted");
    }else{
        const url = "http://localhost:3000/favourite";
        const options = {
            method :"get",
            headers:{
                'Content-Type':"application/json",
                "authorization":`Bearer ${token}`
            }
        }
        fetch(url,options)
            .then((response)=> response.json())
            .then((data)=> data.forEach((data)=>{
                backendData(data) // Function Calling
            }))   
    }
}sendingToServer();