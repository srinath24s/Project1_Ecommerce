
//import { categoryData,products } from "../../backend/data/item";
console.log("Hello World");
//console.log(categoryData);
//console.log(products);




let menuIconEle = document.getElementById("menuIcon");
menuIconEle.addEventListener('click',()=>{
    console.log(menuIconEle.src);
    if(menuIconEle.src == "http://127.0.0.1:5500/ECOM/ECOM/public/Assests/icon/menu.png"){
        menuIconEle.src = '../../../public/Assests/icon/twitter.png';
    }else {
        menuIconEle.src = '../../../public/Assests/icon/menu.png';
    }
// document.getElementById("menuIconBurger").classList.toggle('toggleNavLinks');
// document.getElementById("menuIconCross").classList.toggle('toggleNavLinks');
document.getElementById("select").classList.toggle('toggleNavLinks');
document.getElementById("searchContainer").classList.toggle('searchContainerHide');
})

// // slide bar//
// let incEle = document.getElementById("inc");
// let decEle = document.getElementById("dec");
// let containerEle = document.getElementById("container");

// var count =0;
// // Auto Change Slides
// setInterval(()=>{
//     if((count<=0)&&(count>=(-600)) ) {
//         count=count - 100;
//         console.log("Forward",count)
//         containerEle.style.transform=`translateX(${count}vw)`;
//     }else {
//         clearInterval();
//        // count=0;
//     }
   
// },1000);

// incEle.addEventListener('click',()=>{
// if((count<=0)&&(count>=(-600)) ) {
//     count=count - 100;
//     console.log("Forward",count)
//     containerEle.style.transform=`translateX(${count}vw)`;
// }
// });

// decEle.addEventListener('click',()=>{
//     if(count<0){
//         count=count + 100;
//         console.log( "Backward",count)
//         containerEle.style.transform=`translateX(${count}vw)`;

//     }
// });
let incEle = document.getElementById("inc");
let decEle = document.getElementById("dec");
let containerEle = document.getElementById("container");

var count =0;

// Auto Change Slides
setInterval(()=>{
    if((count<=0)&&(count>=(-600)) ) {
        count=count - 100;
        console.log("Forward",count)
        containerEle.style.transform=`translateX(${count}vw)`;
    }else {
        clearInterval();
       // count=0;
    }
   
},5000);


incEle.addEventListener('click',()=>{
    // Slides length -2
   if((count<=0)&&(count>=(-600)) ) {
    count=count - 100;
    console.log("Forward",count)
    containerEle.style.transform=`translateX(${count}vw)`;
   }
});

decEle.addEventListener('click',()=>{
    if(count<0){
        count=count + 100;
        console.log( "Backward",count)
        containerEle.style.transform=`translateX(${count}vw)`;

    }
});


// Dynamic Category
function Category() {
    let categoryContainer = document.getElementById("categoryContainer");

    let divEle = document.createElement("div");
    divEle.classList.add("categoryImgBlock");
    categoryContainer.appendChild(divEle);

    let imgEle = document.createElement("img");
    imgEle.classList.add("categoryimg");
    imgEle.src = "../../../public/Assests/kids.png";
    divEle.appendChild(imgEle);

}
// let CategoryData = [
//     {
//         img:"",
//         name:"Dres"
//     },
    
//     {
    
//     },

//     {

//     },

//     {

//     },
// ]





/* 
 <div class="categoryImgBlock">
        <img src="../../../public/Assests/kids.png" class="categoryimg">
</div>
*/


//Dynamic  Buy Category//
function product() {
    let productsContainer = document.getElementById("productsContainer");
     
    let divEle =document.createElement("div");
    divEle.classList.add("eachProductContainer");
    productsContainer.appendChild(divEle);

    let imgEle = document.createElement("img");
    imgEle.classList.add("eachProductContainerImg");
    imgEle.src = "../../../public/Assests/both.jpeg";
    imgEle.alt ="Product";
    divEle.appendChild(imgEle);

    let btnEle = document.createElement("button");
    btnEle.textContent="BUY NOW";
    btnEle.classList.add("eachProductContainerBtn");
    divEle.appendChild(btnEle);

}

function backendData(data){   // Function definition

    // write Here code for using fetched data

    console.log("Done",data);
}

function sendingToServer(){
    const url = "http://localhost:3000/products";
    const options = {
        method :"get",
        headers:{
            'Content-Type':"application/json"
        }
    }
    fetch(url,options)
    .then((response)=> response.json())
    .then((data)=> data.forEach((data)=>{
        backendData(data)
    }))  // Function Calling 
}sendingToServer();












