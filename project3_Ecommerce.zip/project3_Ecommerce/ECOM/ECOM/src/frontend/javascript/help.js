
function product() {
    let productsContainer = document.getElementById("helpContainer");
    let divOuterEle =document.createElement("div");
    divOuterEle.classList.add("eachItemContainer");
    productsContainer.appendChild(divOuterEle);
     
    let divEle =document.createElement("div");
    divEle.classList.add("eachProductContainer");
    divOuterEle.appendChild(divEle);

    let imgEle = document.createElement("img");
    imgEle.classList.add("eachProductContainerImg");
    imgEle.src = "../../../public/Assests/both.jpeg";
    imgEle.alt ="Product";
    divEle.appendChild(imgEle);

    let btnEle = document.createElement("button");
    btnEle.textContent="ADD TO CART";
    btnEle.classList.add("eachProductContainerBtn");
    divEle.appendChild(btnEle);


    
    let divSaveEle = document.createElement("div");
    divSaveEle.classList.add("fotter");
    divOuterEle.appendChild(divSaveEle);

    // let butEle = document.createElement("button");
    // butEle.textContent = "REMOVE";
    // butEle.classList.add("btn");
    // divSaveEle.appendChild(butEle);

    let buEle = document.createElement("button");
    buEle.textContent = "DELETE";
    buEle.classList.add("btn");
    divSaveEle.appendChild(buEle);


}




function backendData(data){
    // write Here code for data
    product()
    console.log("Done",data);
 }


function sendingToServer(){
    const token = localStorage.getItem("token")
    // console.log(token)
    if(token == null){
        console.log("You are LogOuted");
    }else{
        const Data = {
            // username:Username,
            // password:Password
        }
        const url = "http://localhost:3000/login";
        const options = {
            method :"post",
            headers:{
                'Content-Type':"application/json"
            },
            body:JSON.stringify(Data)
        }
        const fetchData =   fetch(url,options)
        .then((response)=> response.json())
        .then((data)=> backendData(data))
    }
    
}sendingToServer();






    